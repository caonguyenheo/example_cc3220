/* lhash.h for openSSL */

#include <wolfssl/openssl/lhash.h>