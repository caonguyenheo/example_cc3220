/* The name of this header file is set by the trace recorder code, but the name
of the actual header file is used below. */
#include "lpc18xx.h"
